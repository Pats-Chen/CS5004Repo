package hw2;

/**
 * Author: Jiazhe Chen, NUID: 002162461
 * A enumerated type for hotel room type.
 */
public enum RoomType {
  SINGLE, DOUBLE, FAMILY;
}
