package chess;

/**
 * Author: Jiazhe Chen, NUID: 002162461
 * A enumerated type for chess piece color.
 */
public enum Color {
  WHITE, BLACK;
}